 Schema Name		Schema Version #	Changed since 2011xx#

 datatypes.xsd		2012xx#			Yes
 ecl.xsd		2012xx#			No 
 script.xsd		2012xx#			Yes
 specialized.xsd	2012xx#			Yes
 structures.xsd		2012xx#			Yes
 transport.xsd		2012xx#			Yes