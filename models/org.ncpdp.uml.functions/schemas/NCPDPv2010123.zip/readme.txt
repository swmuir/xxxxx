 Schema Name		Schema Version #	Changed since 2010122

 datatypes.xsd		2010122 		No
 ecl.xsd		2010123 		Yes
 script.xsd		2010122			No
 specialized.xsd	2010122			No
 structures.xsd		2010123 		Yes
 transport.xsd		2010122			No